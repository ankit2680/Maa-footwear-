// Auto-generated seed data — mirrors data/products.json
// This is the demo "database". In production this is replaced by MySQL via php/api/products.php
const MAA_SEED_PRODUCTS = [
  {
    "id": 1,
    "name": "Air Stride Runner",
    "brand": "Nova Sport",
    "category": "sports-shoes",
    "gender": "men",
    "images": [
      "images/products/product-1-1.svg",
      "images/products/product-1-2.svg"
    ],
    "sizes": [
      6,
      7,
      8,
      9,
      10,
      11
    ],
    "colors": [
      "Amber",
      "Black"
    ],
    "material": "Mesh & EVA Sole",
    "mrp": 3499,
    "price": 2399,
    "stock": 18,
    "description": "A lightweight daily trainer built for long runs and gym days. Breathable knit upper, cushioned midsole and a grippy rubber outsole keep every stride comfortable from the first kilometre to the last.",
    "featured": true,
    "bestSeller": true,
    "newArrival": false,
    "rating": 4.6
  },
  {
    "id": 2,
    "name": "Urban Court Sneaker",
    "brand": "Cityfeet",
    "category": "sneakers",
    "gender": "men",
    "images": [
      "images/products/product-2-1.svg",
      "images/products/product-2-2.svg"
    ],
    "sizes": [
      7,
      8,
      9,
      10,
      11
    ],
    "colors": [
      "White",
      "Rust"
    ],
    "material": "Canvas & Rubber Sole",
    "mrp": 2999,
    "price": 2199,
    "stock": 24,
    "description": "Classic low-top silhouette with a padded collar and vulcanised rubber sole. An everyday sneaker that pairs equally well with joggers or jeans.",
    "featured": true,
    "bestSeller": false,
    "newArrival": true,
    "rating": 4.4
  },
  {
    "id": 3,
    "name": "Trailblaze High-Top",
    "brand": "Nova Sport",
    "category": "sports-shoes",
    "gender": "men",
    "images": [
      "images/products/product-3-1.svg",
      "images/products/product-3-2.svg"
    ],
    "sizes": [
      7,
      8,
      9,
      10
    ],
    "colors": [
      "Moss Green",
      "Black"
    ],
    "material": "Synthetic Leather",
    "mrp": 4299,
    "price": 3299,
    "stock": 9,
    "description": "Ankle-supporting high-top designed for trail walks and rugged terrain. Reinforced toe cap and deep-lugged sole for reliable grip.",
    "featured": false,
    "bestSeller": true,
    "newArrival": false,
    "rating": 4.5
  },
  {
    "id": 4,
    "name": "Everyday Slip-On Loafer",
    "brand": "Comfort Walk",
    "category": "sneakers",
    "gender": "men",
    "images": [
      "images/products/product-4-1.svg",
      "images/products/product-4-2.svg"
    ],
    "sizes": [
      6,
      7,
      8,
      9,
      10,
      11
    ],
    "colors": [
      "Ink",
      "Tan"
    ],
    "material": "PU Leather",
    "mrp": 2199,
    "price": 1599,
    "stock": 31,
    "description": "No-lace comfort loafer with memory-foam footbed. Slide in and go \u2014 ideal for the shop counter to the evening walk.",
    "featured": false,
    "bestSeller": false,
    "newArrival": true,
    "rating": 4.2
  },
  {
    "id": 5,
    "name": "Blossom Ballet Flat",
    "brand": "Elira",
    "category": "sneakers",
    "gender": "women",
    "images": [
      "images/products/product-5-1.svg",
      "images/products/product-5-2.svg"
    ],
    "sizes": [
      4,
      5,
      6,
      7,
      8
    ],
    "colors": [
      "Blush Pink",
      "Black"
    ],
    "material": "Soft PU",
    "mrp": 1899,
    "price": 1349,
    "stock": 22,
    "description": "A soft, rounded-toe ballet flat with cushioned insole \u2014 light enough for all-day wear, elegant enough for the evening.",
    "featured": true,
    "bestSeller": true,
    "newArrival": false,
    "rating": 4.7
  },
  {
    "id": 6,
    "name": "Meadow Canvas Sneaker",
    "brand": "Cityfeet",
    "category": "sneakers",
    "gender": "women",
    "images": [
      "images/products/product-6-1.svg",
      "images/products/product-6-2.svg"
    ],
    "sizes": [
      4,
      5,
      6,
      7,
      8
    ],
    "colors": [
      "White",
      "Blue"
    ],
    "material": "Canvas",
    "mrp": 2499,
    "price": 1899,
    "stock": 15,
    "description": "Breathable canvas sneaker with a flexible sole, made for long shopping days and weekend errands alike.",
    "featured": false,
    "bestSeller": false,
    "newArrival": true,
    "rating": 4.3
  },
  {
    "id": 7,
    "name": "Pulse Training Shoe",
    "brand": "Nova Sport",
    "category": "sports-shoes",
    "gender": "women",
    "images": [
      "images/products/product-7-1.svg",
      "images/products/product-7-2.svg"
    ],
    "sizes": [
      4,
      5,
      6,
      7,
      8
    ],
    "colors": [
      "Rust",
      "Black"
    ],
    "material": "Mesh & EVA Sole",
    "mrp": 3199,
    "price": 2399,
    "stock": 13,
    "description": "Responsive cushioning and a snug knit fit designed for studio workouts, brisk walks and everything in between.",
    "featured": true,
    "bestSeller": false,
    "newArrival": false,
    "rating": 4.5
  },
  {
    "id": 8,
    "name": "Riviera Flat Sandal",
    "brand": "Elira",
    "category": "sandals",
    "gender": "women",
    "images": [
      "images/products/product-8-1.svg",
      "images/products/product-8-2.svg"
    ],
    "sizes": [
      4,
      5,
      6,
      7,
      8
    ],
    "colors": [
      "Tan",
      "Gold"
    ],
    "material": "Genuine Leather",
    "mrp": 1799,
    "price": 1299,
    "stock": 20,
    "description": "Hand-finished leather straps over a cushioned footbed \u2014 an easy sandal that moves from beach to brunch.",
    "featured": false,
    "bestSeller": true,
    "newArrival": false,
    "rating": 4.4
  },
  {
    "id": 9,
    "name": "Cloud Step Slipper",
    "brand": "Comfort Walk",
    "category": "slippers",
    "gender": "women",
    "images": [
      "images/products/product-9-1.svg",
      "images/products/product-9-2.svg"
    ],
    "sizes": [
      4,
      5,
      6,
      7,
      8
    ],
    "colors": [
      "Blush Pink",
      "Grey"
    ],
    "material": "Memory Foam",
    "mrp": 999,
    "price": 699,
    "stock": 40,
    "description": "Ultra-soft indoor slipper with a memory-foam sole that cushions every step around the house.",
    "featured": false,
    "bestSeller": false,
    "newArrival": true,
    "rating": 4.1
  },
  {
    "id": 10,
    "name": "Little Champ Sports Shoe",
    "brand": "KidStep",
    "category": "sports-shoes",
    "gender": "kids",
    "images": [
      "images/products/product-10-1.svg",
      "images/products/product-10-2.svg"
    ],
    "sizes": [
      1,
      2,
      3,
      4,
      5
    ],
    "colors": [
      "Blue",
      "Amber"
    ],
    "material": "Mesh & Rubber Sole",
    "mrp": 1699,
    "price": 1199,
    "stock": 26,
    "description": "Durable, machine-washable sports shoe with a Velcro strap, built to keep up with playground energy.",
    "featured": true,
    "bestSeller": true,
    "newArrival": false,
    "rating": 4.6
  },
  {
    "id": 11,
    "name": "Junior Bounce Sneaker",
    "brand": "KidStep",
    "category": "sneakers",
    "gender": "kids",
    "images": [
      "images/products/product-11-1.svg",
      "images/products/product-11-2.svg"
    ],
    "sizes": [
      1,
      2,
      3,
      4,
      5
    ],
    "colors": [
      "White",
      "Rust"
    ],
    "material": "Canvas",
    "mrp": 1499,
    "price": 999,
    "stock": 33,
    "description": "Easy slip-on sneaker with a soft elastic collar, sized for growing feet and everyday school wear.",
    "featured": false,
    "bestSeller": false,
    "newArrival": true,
    "rating": 4.3
  },
  {
    "id": 12,
    "name": "Splash Kids Sandal",
    "brand": "KidStep",
    "category": "sandals",
    "gender": "kids",
    "images": [
      "images/products/product-12-1.svg",
      "images/products/product-12-2.svg"
    ],
    "sizes": [
      1,
      2,
      3,
      4,
      5
    ],
    "colors": [
      "Blue",
      "Pink"
    ],
    "material": "EVA",
    "mrp": 899,
    "price": 599,
    "stock": 45,
    "description": "Quick-dry EVA sandal with a back strap for a secure fit \u2014 perfect for water play and summer days.",
    "featured": false,
    "bestSeller": true,
    "newArrival": false,
    "rating": 4.2
  },
  {
    "id": 13,
    "name": "Home Comfort Slipper",
    "brand": "Comfort Walk",
    "category": "slippers",
    "gender": "men",
    "images": [
      "images/products/product-13-1.svg",
      "images/products/product-13-2.svg"
    ],
    "sizes": [
      6,
      7,
      8,
      9,
      10,
      11
    ],
    "colors": [
      "Black",
      "Ink"
    ],
    "material": "PU & Foam",
    "mrp": 899,
    "price": 599,
    "stock": 38,
    "description": "A wide, breathable slipper with an anti-skid sole \u2014 built for comfort around the house.",
    "featured": false,
    "bestSeller": false,
    "newArrival": false,
    "rating": 4.0
  },
  {
    "id": 14,
    "name": "Desert Strap Sandal",
    "brand": "Comfort Walk",
    "category": "sandals",
    "gender": "men",
    "images": [
      "images/products/product-14-1.svg",
      "images/products/product-14-2.svg"
    ],
    "sizes": [
      7,
      8,
      9,
      10,
      11
    ],
    "colors": [
      "Tan",
      "Black"
    ],
    "material": "Genuine Leather",
    "mrp": 1999,
    "price": 1499,
    "stock": 17,
    "description": "Rugged leather sandal with adjustable straps and a contoured footbed for all-day outdoor comfort.",
    "featured": true,
    "bestSeller": false,
    "newArrival": false,
    "rating": 4.4
  },
  {
    "id": 15,
    "name": "Marathon Pro Runner",
    "brand": "Nova Sport",
    "category": "sports-shoes",
    "gender": "men",
    "images": [
      "images/products/product-15-1.svg",
      "images/products/product-15-2.svg"
    ],
    "sizes": [
      7,
      8,
      9,
      10,
      11
    ],
    "colors": [
      "Black",
      "Amber"
    ],
    "material": "Engineered Mesh",
    "mrp": 4999,
    "price": 3799,
    "stock": 11,
    "description": "Performance running shoe with dual-density cushioning and a carbon-inspired shank plate for propulsion.",
    "featured": true,
    "bestSeller": true,
    "newArrival": true,
    "rating": 4.8
  },
  {
    "id": 16,
    "name": "Petal Wedge Sandal",
    "brand": "Elira",
    "category": "sandals",
    "gender": "women",
    "images": [
      "images/products/product-16-1.svg",
      "images/products/product-16-2.svg"
    ],
    "sizes": [
      4,
      5,
      6,
      7,
      8
    ],
    "colors": [
      "Blush Pink",
      "Tan"
    ],
    "material": "Synthetic Leather",
    "mrp": 2299,
    "price": 1699,
    "stock": 14,
    "description": "A low wedge sandal with a cushioned strap \u2014 comfortable height for festive days and evening outings.",
    "featured": false,
    "bestSeller": false,
    "newArrival": true,
    "rating": 4.3
  },
  {
    "id": 17,
    "name": "Weekend Espadrille",
    "brand": "Elira",
    "category": "sneakers",
    "gender": "women",
    "images": [
      "images/products/product-17-1.svg",
      "images/products/product-17-2.svg"
    ],
    "sizes": [
      4,
      5,
      6,
      7,
      8
    ],
    "colors": [
      "Tan",
      "White"
    ],
    "material": "Canvas & Jute Sole",
    "mrp": 1999,
    "price": 1449,
    "stock": 19,
    "description": "Jute-trimmed espadrille sneaker with a soft canvas upper \u2014 a relaxed weekend staple.",
    "featured": false,
    "bestSeller": false,
    "newArrival": false,
    "rating": 4.1
  },
  {
    "id": 18,
    "name": "Bounce Play Slipper",
    "brand": "KidStep",
    "category": "slippers",
    "gender": "kids",
    "images": [
      "images/products/product-18-1.svg",
      "images/products/product-18-2.svg"
    ],
    "sizes": [
      1,
      2,
      3,
      4,
      5
    ],
    "colors": [
      "Blue",
      "Pink"
    ],
    "material": "EVA Foam",
    "mrp": 699,
    "price": 449,
    "stock": 50,
    "description": "Bouncy, lightweight indoor slipper with cartoon-friendly colours kids love to wear.",
    "featured": false,
    "bestSeller": true,
    "newArrival": false,
    "rating": 4.0
  }
];
